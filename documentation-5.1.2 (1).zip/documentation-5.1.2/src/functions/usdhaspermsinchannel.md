# $hasPermsInChannel

This function returns whether or not the specified user has the given perms in the specified channel. Returns boolean

