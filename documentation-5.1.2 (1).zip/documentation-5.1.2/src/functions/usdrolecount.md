---
description: Returns the amount of roles in this guild
---

# $roleCount

This function returns the amount of roles in the current guild

```javascript
bot.command({
name: "serverinfo", 
code: `
Roles in this guild: $roleCount` 
})
```



