---
description: Stop the bot from playing songs
---

# $stopSong

This function makes the bot stops all songs from queue and leaves VC

```javascript
bot.command({
name:"stop",
code:`$stopSong`
})
```

