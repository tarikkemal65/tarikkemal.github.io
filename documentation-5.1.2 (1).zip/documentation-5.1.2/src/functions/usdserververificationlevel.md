---
description: Sends the verification level of the current server
---

# $serverVerificationLevel

This function returns the current guild's server verification level

```javascript
bot.command({
name: "serverVerificationLvl",
code: `Server Verification Level: $serverVerificationLevel`
})
```

![](<../../.gitbook/assets/image (32).png>)
