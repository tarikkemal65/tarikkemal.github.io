---
description: Returns a random ID from all guilds the bot is in
---

# $randomGuildID

This function returns a random guild ID that the bot is in

```javascript
bot.command({
name: "randomguildID",
code: `Random Guild ID: $randomGuildID`
})
```

