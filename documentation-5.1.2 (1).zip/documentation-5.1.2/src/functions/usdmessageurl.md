---
description: Returns the message link to the author's message.
---

# $messageURL

This function simple returns the message link to the command message.

#### Usage:

```text
$messageURL
```



