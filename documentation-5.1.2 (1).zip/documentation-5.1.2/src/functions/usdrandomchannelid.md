---
description: Return a random channel ID from the current Guild
---

# $randomChannelID

This function returns a random channel's ID in the current guild

```javascript
bot.command({
name:"randomchannelid",
code:`Random Channel ID: $randomChannelID`
})
```

