# $loopSong

Loops the current song in queue.

Example:

```javascript
bot.command({
    name: "loop-song",
    code: `
    Looping current song.
    $loopSong
    `
})
```

