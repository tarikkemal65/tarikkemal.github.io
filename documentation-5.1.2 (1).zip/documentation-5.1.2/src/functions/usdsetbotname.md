---
description: Changes the bot's name to the given text
---

# $setBotName

This function set's the bot's username

```javascript
$setBotName[text]
```

```javascript
bot.command({
name: "setbotname",
code: `Set the bots name! 
$setBotName[Aoi.JS]`
})
```

{% hint style="danger" %}
THIS SHOULD BE RESTRICTED TO BOT DEV ONLY
{% endhint %}

