---
description: Resume the song from being paused
---

# $resumeSong

This function resumes a song after being paused

```javascript
bot.command({
name:"resume",
code: `$resumeSong`
})
```



