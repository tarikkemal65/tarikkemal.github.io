---
description: Returns all the server emojis
---

# $serverEmojis

This function returns every emoji the current server has

```javascript
bot.command({
name: serverEmojis",
code: `All Server Emojis: $serverEmojis`
})
```

