---
description: Returns the content filter of the guild
---

# $serverContentFilter

This function returns the content filter of the current guild

```javascript
bot.command({
name: "serverContentFilter",
code: `Server Filter: $serverContentFilter`
})
```

![Example](<../../.gitbook/assets/image (55).png>)
