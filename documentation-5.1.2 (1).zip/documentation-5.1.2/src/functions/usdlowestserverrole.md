# $lowestServerRole

This function returns the lowest role for the current guild.

```javascript
bot.command({
name: "role", 
code: `$serverName's lowest Role:
$lowestServerRole`
})
```

