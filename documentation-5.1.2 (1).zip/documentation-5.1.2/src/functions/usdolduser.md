---
description: >-
  This function holds data of the old user, used in update user callback, or
  else any data will be empty.
---

# $oldUser

This function is only useable in bot.userUpdateCommand\(\) commands. Examples can be found in the callback page:

{% page-ref page="../callbacks/bot.onuserupdate.md" %}



