---
description: >-
  Holds data for the member after the update, might be a good idea to check
  partial option before accessing any property.
---

# $newMember

This function is only useable in the bot.onMemberUpdate callback or else it won't give any data. Examples can be found in the callback page.

{% page-ref page="../callbacks/bot.onmemberupdate.md" %}



