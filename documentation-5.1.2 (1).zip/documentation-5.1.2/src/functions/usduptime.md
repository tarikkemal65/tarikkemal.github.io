---
description: Return the uptime of the Bot
---

# $uptime

This function returns how long the bot's been online

```javascript
bot.command({
name:"uptime",
code:`$uptime` //Ex: 1h 41m 50s
})
```

