---
description: Logs given text into console
---

# $log

This function logs the given &lt;text&gt; in the console

```javascript
$log[text]
```

```javascript
bot.command({
name: "consoleLog",
code: `Logged: Hello World
$log[Hello World]`
})
```

