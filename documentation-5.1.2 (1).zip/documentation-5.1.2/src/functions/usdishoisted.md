# $isHoisted

This function checks if the role is hoisted or not. Returns boolean

```text
$isHoisted[role id]
```

Using the function

```javascript
bot.command({
    name: "ishoisted",
    code: `$isHoisted[773353338393329675]`
})
```

