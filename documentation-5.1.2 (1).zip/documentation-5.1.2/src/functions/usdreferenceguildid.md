---
description: Returns the ID of the channel where the user replied in
---

# $referenceGuildID

This function gets the current guild ID the user replied in

```javascript
bot.command({
name: "referencechannel",
code: `Reply Guild ID: $referenceGuildID`
})
```

![Heres an example (I know it says message ID but its basically the same)](<../../.gitbook/assets/image (14) (4) (4) (3) (1).png>)
