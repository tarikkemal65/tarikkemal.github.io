---
description: Returns guild owner's id
---

# $ownerID

This function returns the server owner's id of the current guild

```javascript
bot.command({
name: "ownerID",
code: `Server Owners ID: $ownerID` //Ex: Returns 535566311942651924
})
```

