---
description: This function updates all your commands in your command handler
---

# $updateCommands

This function updates all your commands in your command handler

#### Usage

```javascript
bot.command({
name: "updateCommands",
code: `$updateCommands Updated all your commands`
//You should put $onlyForIDs
})
```

