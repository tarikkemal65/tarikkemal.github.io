---
description: Subtracts all values
---

# $sub

This function subtracts all the values given

```text
$sub[value1;value2;...]
```

```javascript
bot.command({
name: "sub",
code: `$sub[5;5]` //Returns 0
})
```

