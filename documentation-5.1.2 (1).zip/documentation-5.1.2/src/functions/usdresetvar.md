---
description: Resets global variable value
---

# $resetVar

This function resets a global variable

```text
$resetVar[variable]
```

```javascript
bot.command({
name: "resetglobalvar",
code: `Resetted global XP
$resetVar[globalXP]`
})
```

