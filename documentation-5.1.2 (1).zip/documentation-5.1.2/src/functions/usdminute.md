# $minute

This function returns the current minute

```javascript
bot.command({
name: "minute",
code: `Minute: $minute`
//Returns: 23
})
```

