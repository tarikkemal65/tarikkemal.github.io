---
description: Uppercases all characters in the given text
---

# $toUppercase

This function uppercases all characters in &lt;text&gt;

```javascript
$toUppercase[text]
```

```javascript
bot.command({
name: "toUppercase",
code: `$toUppercase[hello]` //Returns: HELLO
})
```

