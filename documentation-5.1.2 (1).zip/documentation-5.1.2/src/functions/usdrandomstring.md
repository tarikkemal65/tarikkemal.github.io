---
description: Generates a random string
---

# $randomString

This function generates and returns a random string

```text
$randomString[length]
```

```javascript
bot.command({
name: "randomstring",
code: `Heres your string: $randomString[8]`
//EX: oqipUfKc
})
```

