---
description: Get the Bot Ping.
---

# $ping

This function returns websocket ping

```javascript
bot.command({
name: "ping", 
code: `Pong! \`$ping\`` //Ex: Pong! 45
})
```

