---
description: Rounds a number to the given unit
---

# $roundTenth

```text
$roundTenth[number;unit]
```

```javascript
bot.command({
name: "roundtenth",
code: `$roundTenth[2.3942749034;2]` //Returns 2.39
})
```

