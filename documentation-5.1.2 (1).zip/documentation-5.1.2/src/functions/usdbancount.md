# $banCount

This function returns how many bans the current guild has

#### Usage

```javascript
bot.command({
name: "banCount",
code: `Bans: $banCount`
```

