---
description: Slices Message to return a cutted message from X to Y or just X
---

# $messageSlice

This function slices the message to return sliced message from X, or X & Y

```text
$messageSlice[x;y (optional)]
```

```javascript
bot.command({
name:"slicedMessage",
code:`$messageSlice[1;3]`
})
```

