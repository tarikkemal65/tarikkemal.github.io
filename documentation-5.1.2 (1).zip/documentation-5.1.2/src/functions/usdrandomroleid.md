---
description: Returns a random role id from the current guild
---

# $randomRoleID

This function returns a random role's id from the current guild

```javascript
bot.command({
name: "randomRoleID",
code: `Random Role ID: $randomRoleID`
})
```

