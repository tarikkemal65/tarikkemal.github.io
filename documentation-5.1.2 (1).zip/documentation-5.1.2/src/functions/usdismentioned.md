---
description: Checks if role/channel/user/@everyone was mentioned (Boolean)
---

# $isMentioned

$isMentioned\[userID/roleID/channelID/everyone\]

```text
bot.command({
name: "was-mentioned",
code: `$isMentioned[535566311942651924]`
})
```

