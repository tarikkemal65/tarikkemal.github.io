---
description: Checks if given user ID is defeaned. Returns true/false
---

# $isDefeaned

This function checks if the given user ID is defeaned. Returns boolean

```text
$isDefeaned[user ID]
```

```javascript
bot.command({
name: "isDefeaned",
code: `Is Defeaned: $isDefeaned[535566311942651924]`
})
```

