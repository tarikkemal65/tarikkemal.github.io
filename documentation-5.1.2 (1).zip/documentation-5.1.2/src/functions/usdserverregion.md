---
description: Returns the current guild's region
---

# $serverRegion

This function returns the current guild's voice region

```javascript
bot.command({
name: "serverRegion",
code: `Servers Region: $serverRegion`
})
```

![](<../../.gitbook/assets/image (60).png>)
