---
description: 'Get the Server Invite Link, or Enter Server ID.'
---

# $getServerInvite

This function returns the current guild's invite

```javascript
bot.command({
name: "invite", 
code: `
$getServerInvite`
})
```

