---
description: Returns the amount of boosts this server has
---

# $serverBoostCount

This function returns how many boosts the current guild has

```javascript
bot.command({
name: "boosts", 
code: `
This server have $serverBoostCount boosts!` 
})
```



