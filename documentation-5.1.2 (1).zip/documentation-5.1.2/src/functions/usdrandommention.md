---
description: Return a random mentioned user from the current Guild
---

# $randomMention

This function returns a random user and mentions them from in the current guild

```text
bot.command({
name:"randomMention",
code:`Random Mention: $randomMention`
})
```

