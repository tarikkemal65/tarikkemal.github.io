---
description: Check if the Link is a valid invite.
---

# $isValidInvite

{% hint style="info" %}
Returns `true` or `false`
{% endhint %}

```text
bot.command({
name: "isvalid", 
code: `
$isValidInvite[$message]`
})
```



