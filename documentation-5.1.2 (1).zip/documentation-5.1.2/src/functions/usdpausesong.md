---
description: Pause the current song
---

# $pauseSong

This function pauses the currently playing song

```javascript
bot.command({
name:"pause",
code:`$pauseSong`
})
```

