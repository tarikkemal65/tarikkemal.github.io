---
description: Returns the specified roles position
---

# $rolePosition

This function returns the position of the specified role

```javascript
$rolePosition[role ID]
```

```javascript
bot.command({
name: "rolePos",
code: `Role Position: $rolePosition[773353338393329675]`
})
```

