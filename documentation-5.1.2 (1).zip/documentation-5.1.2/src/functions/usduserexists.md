---
description: Checks if the given user ID exists
---

# $userExists

This function checks if the given user ID exists in discord

```text
$userExists[user ID]
```

```javascript
bot.command({
name: "userExists",
code: `Does 608358453580136499 exist? $userExists[608358453580136499]`
})
```

