# $isValidLink

This function checks if the given link is valid or not

```text
$isValidLink[link]
```

```javascript
bot.command({
name: "isLink", 
code: `Is Link: $isValidLink[https://aoi.js.org]` 
})
```

