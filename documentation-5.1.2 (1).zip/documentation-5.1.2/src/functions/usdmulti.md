---
description: $multi will multiply in the given args.
---

# $multi

This function will multiply all values

```text
$multi[value1;value2;...]
```

```javascript
bot.command({
        name: "multi",
        code: `$multi[1;5]` //Returns 5
})
```

