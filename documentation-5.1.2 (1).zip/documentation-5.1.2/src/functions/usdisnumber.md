---
description: Checks if the value is a number or not.
---

# $isNumber

This function checks if the &lt;message&gt; is a number or not. Returns boolean

```javascript
$isNumber[text]
```

```javascript
bot.command({
name: "isnumber", 
code: `
$isNumber[12432]` //This will return true
})
```

