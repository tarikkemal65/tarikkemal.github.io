# $isPrune

This function displays wether or not the queue message is pruned. Returns true or false.

Example:

```javascript
bot.command({
    name: "isprune",
    code: `
    $isPrune
    `
})
```

