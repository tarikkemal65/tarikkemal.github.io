---
description: Adds images to embed.
---

# $image

This function adds an image to the embed

```text
$image[index;url;Name (Optional)]
```

```javascript
bot.command({
name: "image", 
code: `$image[1;https://cdn.discordapp.com/emojis/773437619207012422.png?v=1]`
})
```

