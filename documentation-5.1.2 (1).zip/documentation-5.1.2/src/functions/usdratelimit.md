---
description: Holds data for rate limit callback.
---

# $rateLimit

This function is used to hold data about a rate limit in the bot.onRateLimit\(\) callback and can be used only in the bot.rateLimitCommand:

{% page-ref page="../callbacks/bot.onratelimit.md" %}



