---
description: Skip the current song to next queue song
---

# $skipSong

This function skips to the next song in the queue

```javascript
bot.command({
name:"skip",
code:`$skipSong`
})
```

