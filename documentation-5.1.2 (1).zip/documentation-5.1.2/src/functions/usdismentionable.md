# $isMentionable

This function checks if a role is mentionable or not. Returns boolean

```text
$isMentionable[role ID]
```

Using this function

```javascript
bot.command({
    name: "ismentionable",
    code: `$isMentionable[773353338393329675]`
})
```

