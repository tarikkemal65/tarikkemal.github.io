---
description: Returns an user ID with given user name
---

# $userID

This function returns the user ID of the given username

```javascript
$userID[username]
```

```javascript
bot.command({
name: "user",
code: `$userID[Kubaturi]` //Returns 535566311942651924
})
```

