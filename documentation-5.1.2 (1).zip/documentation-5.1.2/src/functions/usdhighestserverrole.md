# $highestServerRole

This function returns the current server's highest role

```javascript
bot.command({
name: "role", 
code: `$serverName's Highest Role:
$highestServerRole`
})
```

