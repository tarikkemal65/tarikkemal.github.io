# $serverBoostLevel

This function returns the server boost level.

```javascript
bot.command({
name: "boostLevel",
code: `
Boost Level: $serverBoostLevel
`
})
```

