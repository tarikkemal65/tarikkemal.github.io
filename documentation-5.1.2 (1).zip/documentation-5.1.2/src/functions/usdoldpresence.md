---
description: >-
  The function that holds old data of the user's presence, used in update
  presence callback, or else any data will be empty.
---

# $oldPresence

This function is only useable in [bot.onPresenceUpdate.](../callbacks/bot.onpresenceupdate.md) Examples can be found in the callback page.

{% page-ref page="../callbacks/bot.onpresenceupdate.md" %}



