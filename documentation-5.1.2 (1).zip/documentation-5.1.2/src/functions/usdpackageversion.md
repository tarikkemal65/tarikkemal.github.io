# $packageVersion

This function returns the current version of aoi.js you are running

```javascript
bot.command({
    name: 'info',
    code: `Aoi.JS: $packageVersion`
})
```

