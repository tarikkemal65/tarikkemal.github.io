---
description: Checks if the object structure is partial or not
---

# $partial

Emptiness...

