---
description: Returns the amount of servers the bot is in.
---

# $serverCount

This function returns how many servers the bot is in

```javascript
bot.command({
name: "count",
code: `I am in $serverCount servers!`
})
```

