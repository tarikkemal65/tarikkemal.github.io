---
description: Rounds a number to the unit
---

# $round

This function rounds the number to the closest unit

```javascript
$round[number]
```

```javascript
bot.command({
name: "round",
code: `$round[2.6]` //Returns 3
})
```

