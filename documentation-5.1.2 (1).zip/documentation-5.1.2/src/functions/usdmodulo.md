---
description: Returns the remainder of the division
---

# $modulo

This function will divide the values, then return the remainder.

```text
$modulo[value1;value2;...]
```

```javascript
bot.command({
name: "remainder",
code: `Remainder: $modulo[5;2]` //Returns 1
})
```

