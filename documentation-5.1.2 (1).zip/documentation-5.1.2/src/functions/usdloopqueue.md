---
description: Loop the current songs in the queue. Returns whether or not it's looping
---

# $loopQueue

This function loops/unloops the whole queue, and returns whether it's looped. Returns boolean

```javascript
bot.command({
name: "loopQueue",
code: `Looped the queue! $loopQueue`
})
```

