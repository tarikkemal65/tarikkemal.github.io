---
description: Sets the current guild's name.
---

# $setGuildName

This function set's the current guild's name with &lt;name&gt;

```text
$setGuildName[name]
```

```javascript
bot.command({
name: "setGuildName",
code: `
Set the guild name
$setGuildName[Aoi.JS]
`
})
```

