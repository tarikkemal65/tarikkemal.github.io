# $shuffleQueue

This function shuffles the queue to play in a randomized list

```javascript
bot.command({
name: "shuffle",
code: `$shuffleQueue I've shuffled the queue!`
})
```

