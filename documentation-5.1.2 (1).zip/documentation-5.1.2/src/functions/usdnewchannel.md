# $newChannel

This function is only useable in [onChannelCreate](../callbacks/bot.onchannelcreate.md) and [onChannelUpdate](../callbacks/bot.onchannelupdate.md). Examples can be found in the callback pages.  


{% page-ref page="../callbacks/bot.onchannelcreate.md" %}

{% page-ref page="../callbacks/bot.onchannelupdate.md" %}







