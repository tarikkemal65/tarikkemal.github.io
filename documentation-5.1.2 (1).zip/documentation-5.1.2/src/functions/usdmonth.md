# $month

This function returns the current month

```javascript
bot.command({
name: "month",
code: `Month: $month`
//Returns: January
})
```

