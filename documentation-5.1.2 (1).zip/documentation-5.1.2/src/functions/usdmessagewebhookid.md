# $messageWebhookID

This function gets the webhook's message ID

```javascript
bot.command({
name: "send-webhook",
code: `$sendWebhook[793312378162642975;paNWUYLC22oL-t2hbYeu3zrwWXNfVxjn4TmDDVTISNVRbytCbptYM4DETJDTPzG-1JcA;Hello!;{title:Embed<3} {color:RANDOM};{title:Embed 2 WOW} {color:RANDOM}]
MessageID: $messageWebhookID
`
})
```

