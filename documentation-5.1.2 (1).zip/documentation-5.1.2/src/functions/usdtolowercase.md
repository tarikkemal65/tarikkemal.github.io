---
description: Lowercases all characters in the given test
---

# $toLowercase

This function lowercases all characters in &lt;text&gt;

```javascript
$toLowercase[text]
```

```javascript
bot.command({
name: "toLowercase",
code: `$toLowercase[HELLO]` //Returns: hello
})
```

