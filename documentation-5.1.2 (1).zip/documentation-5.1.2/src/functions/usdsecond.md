# $second

This function returns the current second

```javascript
bot.command({
name: "Second",
code: `Second: $second`
//Returns: 30
})
```

