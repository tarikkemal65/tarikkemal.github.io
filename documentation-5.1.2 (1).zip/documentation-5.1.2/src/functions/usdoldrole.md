# $oldRole

This function is only useable in bot.roleUpdateCommand\(\) and bot.onRoleDeleteCommand\(\) commands. Examples can be found in the callback pages.

{% page-ref page="../callbacks/bot.onroleupdate.md" %}

{% page-ref page="../callbacks/bot.onroledelete.md" %}



