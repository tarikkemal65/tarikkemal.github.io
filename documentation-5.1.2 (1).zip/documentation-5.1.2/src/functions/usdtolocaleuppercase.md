---
description: Uppercases the first letter of each word in the given text
---

# $toLocaleUppercase

This function uppercases the first character in each argument/word in &lt;text&gt;

```javascript
$toLocaleUppercase[text]
```

```javascript
bot.command({
name: "toLocaleUppercase",
code: `$toLocaleUppercase[aoijs is awesome]` //Returns: Aoijs Is Awesome
})
```

