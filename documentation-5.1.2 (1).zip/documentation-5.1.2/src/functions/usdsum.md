---
description: Sums up all the given number value
---

# $sum

This function adds up all the values

```text
$sum[value1;value2;...]
```

```javascript
bot.command({
name: "sum",
code: `$sum[5;5]` //Returns 10
})
```

