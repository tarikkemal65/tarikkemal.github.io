---
description: The ID of the channel where this user replied in
---

# $referenceChannelID

This function returns the channel ID the user replied in

```javascript
bot.command({
name: "referencechannel",
code: `Reply Channel ID: $referenceChannelID`
})
```

![Heres an example (I know it says MessageID but its basically the same)](<../../.gitbook/assets/image (14) (4) (4) (3) (3).png>)
