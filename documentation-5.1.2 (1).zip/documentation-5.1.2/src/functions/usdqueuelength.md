---
description: Returns the amount of songs in queue
---

# $queueLength

This function returns how many songs are in the queue

```javascript
bot.command({
name: "queuelength",
code: `The queue has $queueLength songs!`
})
```

