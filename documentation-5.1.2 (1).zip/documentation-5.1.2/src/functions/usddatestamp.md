---
description: Returns the current date stamp since 1970
---

# $dateStamp

This function will return the current date stamp

#### Usage

```javascript
bot.command({
name: "dateStamp",
code: `Current Date: $dateStamp`
}) //For example, will return 1610337410014 
```

