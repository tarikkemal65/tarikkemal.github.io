---
description: Return a random User ID from the current Guild/Server
---

# $randomUserID

This function returns a random user ID from the current guild

```text
bot.command({
name:"randomuserid",
code:`$randomUserID - A random user ID from this Guild`
})
```



