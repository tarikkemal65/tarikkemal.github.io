---
description: Checks if given user ID is muted. Returns true/false
---

# $isMuted

This function checks if the given user ID is muted. Returns boolean

```javascript
$isMuted[userID]
```

```javascript
bot.command({
name: "isMuted",
code: `Is Muted: $isMuted[535566311942651924]`
})
```

